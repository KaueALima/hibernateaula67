package br.usjt.usjt_ccp3anmca_jpa_hibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public class TesteInsereUmVeiculo {

	public static void main(String[] args) {
		EntityManager manager = JPAUtil.getEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		Veiculo v = new Veiculo();
		v.setModelo("Terius");
		v.setMarca("MadeInJapan");
		v.setCor("preto");
		v.setAnoDeFabricacao("2000");
		manager.persist(v);
		transaction.commit();
		manager.close();
		JPAUtil.close();
	}

}
