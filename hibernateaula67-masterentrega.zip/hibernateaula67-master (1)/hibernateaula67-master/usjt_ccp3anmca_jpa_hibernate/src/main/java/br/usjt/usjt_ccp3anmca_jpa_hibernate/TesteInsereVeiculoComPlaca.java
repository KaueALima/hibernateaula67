package br.usjt.usjt_ccp3anmca_jpa_hibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

public class TesteInsereVeiculoComPlaca {

	public static void main(String[] args) {
		EntityManager manager = JPAUtil.getEntityManager();
		EntityTransaction transaction = manager.getTransaction();
		transaction.begin();
		Placa p = new Placa();
		p.setIdentificador("KAL-4563");
		p.setCidade("São Paulo-SP");
		manager.persist(p);
		Veiculo v = new Veiculo();
		v.setModelo("Terius");
		v.setMarca("MadeInJapan");
		v.setCor("Preto");
		v.setAnoDeFabricacao("2000");
		v.setPlaca(p);
		manager.persist(v);
		transaction.commit();
		manager.close();
		JPAUtil.close();
	}

}
